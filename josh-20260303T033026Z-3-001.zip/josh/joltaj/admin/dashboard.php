<?php
// admin/dashboard.php
require_once '../includes/admin_auth.php';
$db = get_db();

$users_count   = $db->query("SELECT COUNT(*) as c FROM users")->fetch_assoc()['c'];
$products_count= $db->query("SELECT COUNT(*) as c FROM products")->fetch_assoc()['c'];
$total_stock   = $db->query("SELECT SUM(stock) as s FROM products")->fetch_assoc()['s'] ?? 0;
$recent_users  = $db->query("SELECT id, fullname, email, created_at FROM users ORDER BY created_at DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard — Admin</title>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="dashboard">

<?php require_once '../includes/admin_sidebar.php'; ?>

<div class="main-content">
    <div class="topbar">
        <div class="topbar-left">
            <button class="hamburger" id="hamburgerBtn" onclick="toggleSidebar()" aria-label="Toggle menu">
                <span></span><span></span><span></span>
            </button>
            <div class="topbar-title">📊 Dashboard</div>
        </div>
        <div class="topbar-user">
            <div class="avatar"><?= strtoupper(substr($_SESSION['admin_username'], 0, 1)) ?></div>
            <span><?= sanitize($_SESSION['admin_username']) ?></span>
        </div>
    </div>

    <div class="page-content">
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon purple">👥</div>
                <div><div class="stat-number"><?= $users_count ?></div><div class="stat-label">Total Users</div></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon green">🛒</div>
                <div><div class="stat-number"><?= $products_count ?></div><div class="stat-label">Products</div></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon orange">📦</div>
                <div><div class="stat-number"><?= $total_stock ?></div><div class="stat-label">Total Stock</div></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon blue">🛡️</div>
                <div><div class="stat-number">✓</div><div class="stat-label">Secure System</div></div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <div class="card-title">👥 Recent Users</div>
                <a href="users.php" class="btn btn-primary btn-sm">View All</a>
            </div>
            <div class="table-responsive">
                <table>
                    <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Joined</th></tr></thead>
                    <tbody>
                    <?php if (empty($recent_users)): ?>
                        <tr><td colspan="4"><div class="empty-state"><span class="empty-icon">👤</span>No users yet.</div></td></tr>
                    <?php else: foreach ($recent_users as $u): ?>
                        <tr>
                            <td><?= $u['id'] ?></td>
                            <td><?= sanitize(decrypt_data($u['fullname'])) ?></td>
                            <td><?= sanitize(decrypt_data($u['email'])) ?></td>
                            <td><?= date('M d, Y', strtotime($u['created_at'])) ?></td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>

<script src="../assets/js/sidebar.js"></script>
</body>
</html>
