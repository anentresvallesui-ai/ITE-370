// sidebar.js — hamburger / sidebar toggle logic
(function () {
    const sidebar  = document.getElementById('sidebar');
    const overlay  = document.getElementById('sidebarOverlay');
    const hamburger= document.getElementById('hamburgerBtn');
    const DESKTOP  = 1024;

    function isDesktop() { return window.innerWidth >= DESKTOP; }

    // On desktop keep sidebar open unless explicitly toggled
    function initState() {
        if (isDesktop()) {
            sidebar.classList.add('open');
            if (hamburger) hamburger.classList.remove('active');
        } else {
            sidebar.classList.remove('open');
            if (overlay) overlay.classList.remove('active');
            if (hamburger) hamburger.classList.remove('active');
        }
    }

    window.openSidebar = function () {
        sidebar.classList.add('open');
        if (overlay && !isDesktop()) overlay.classList.add('active');
        if (hamburger) hamburger.classList.add('active');
        document.body.style.overflow = isDesktop() ? '' : 'hidden';
    };

    window.closeSidebar = function () {
        sidebar.classList.remove('open');
        if (overlay) overlay.classList.remove('active');
        if (hamburger) hamburger.classList.remove('active');
        document.body.style.overflow = '';
    };

    window.toggleSidebar = function () {
        sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
    };

    // Auto-close on mobile when nav link clicked
    window.autoClose = function () {
        if (!isDesktop()) closeSidebar();
    };

    // Re-evaluate on resize
    let resizeTimer;
    window.addEventListener('resize', function () {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(initState, 120);
    });

    // Keyboard: Escape closes sidebar
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') closeSidebar();
    });

    initState();
}());
