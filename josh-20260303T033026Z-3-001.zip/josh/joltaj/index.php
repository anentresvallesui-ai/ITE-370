<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>JoltAJ — ⚡ Next-Gen Gadget Store</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="auth-wrapper">
<div class="auth-card" style="text-align:center">
    <div class="auth-logo">
        <span class="icon">⚡</span>
        <h1>JoltAJ</h1>
        <p>Your Next-Gen Gadget Store</p>
    </div>
    <div style="display:flex;flex-direction:column;gap:14px;margin-top:24px;">
        <a href="user/login.php" class="btn btn-primary btn-block" style="font-size:16px;padding:14px">
            🛍️ Shop Now
        </a>
        <a href="user/register.php" class="btn btn-success btn-block" style="font-size:15px">
            📝 Create Account
        </a>
    </div>
    <p style="margin-top:20px;font-size:12px;color:var(--text-light)">
        ⚡ Premium Gadgets · Secure Checkout · Fast Delivery
    </p>
</div>
</div>
</body>
</html>
