-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2026 at 11:31 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `joltaj_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `email`, `password`, `created_at`) VALUES
(1, 'joltaj_admin', 'admin@joltaj.com', '$2y$12$e81PajLLci2T8wIqFmuJUeqsoPVlrbNv0p.c4bFPUUzHfB3rOnspq', '2026-02-28 10:19:36');

-- --------------------------------------------------------

--
-- Table structure for table `login_logs`
--

CREATE TABLE `login_logs` (
  `id` int(11) NOT NULL,
  `user_type` enum('admin','user') NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `login_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `login_logs`
--

INSERT INTO `login_logs` (`id`, `user_type`, `user_id`, `ip_address`, `login_time`) VALUES
(1, 'admin', 1, '::1', '2026-02-28 10:21:10'),
(2, 'admin', 1, '::1', '2026-02-28 10:29:45');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `stock`, `image`, `category`, `created_at`, `updated_at`) VALUES
(1, 'iPhone 15 Pro Max', 'Apple A17 Pro chip, 48MP camera, titanium build, 256GB', 89999.00, 20, NULL, 'Smartphones', '2026-02-28 10:19:36', '2026-02-28 10:19:36'),
(2, 'Samsung Galaxy S24 Ultra', 'Snapdragon 8 Gen 3, 200MP, built-in S Pen, 512GB', 79999.00, 15, NULL, 'Smartphones', '2026-02-28 10:19:36', '2026-02-28 10:19:36'),
(3, 'MacBook Air M3', 'Apple M3 chip, 13.6-inch Liquid Retina, 16GB RAM, 512GB SSD', 79999.00, 10, NULL, 'Laptops', '2026-02-28 10:19:36', '2026-02-28 10:19:36'),
(4, 'ASUS ROG Zephyrus G14', 'AMD Ryzen 9, RTX 4060, 14-inch QHD 165Hz, 1TB SSD', 74999.00, 12, NULL, 'Laptops', '2026-02-28 10:19:36', '2026-02-28 10:19:36'),
(5, 'iPad Pro M4 11-inch', 'Apple M4 chip, Ultra Retina XDR OLED, 256GB, Wi-Fi + Cellular', 64999.00, 18, NULL, 'Tablets', '2026-02-28 10:19:36', '2026-02-28 10:19:36'),
(6, 'Samsung Galaxy Tab S9', 'Snapdragon 8 Gen 2, 11-inch AMOLED, 128GB, IP68 rated', 39999.00, 25, NULL, 'Tablets', '2026-02-28 10:19:36', '2026-02-28 10:19:36'),
(7, 'Sony WH-1000XM5', 'Industry-leading noise cancellation, 30hr battery, multipoint', 18999.00, 40, NULL, 'Audio', '2026-02-28 10:19:36', '2026-02-28 10:19:36'),
(8, 'AirPods Pro 2nd Gen', 'Active Noise Cancellation, Adaptive Transparency, USB-C case', 16999.00, 35, NULL, 'Audio', '2026-02-28 10:19:36', '2026-02-28 10:19:36'),
(9, 'Apple Watch Series 9', 'S9 chip, Double Tap gesture, 41mm Always-On Retina display', 24999.00, 30, NULL, 'Wearables', '2026-02-28 10:19:36', '2026-02-28 10:19:36'),
(10, 'Samsung Galaxy Watch 6', 'BioActive sensor, sleep coaching, 40mm sapphire crystal', 14999.00, 28, NULL, 'Wearables', '2026-02-28 10:19:36', '2026-02-28 10:19:36'),
(11, 'GoPro Hero 12 Black', '5.3K video, HyperSmooth 6.0, 27MP photo, waterproof to 10m', 24999.00, 22, NULL, 'Cameras', '2026-02-28 10:19:36', '2026-02-28 10:19:36'),
(12, 'DJI Mini 4 Pro', '4K/60fps drone, obstacle sensing, 34-min flight, 249g weight', 49999.00, 8, NULL, 'Drones', '2026-02-28 10:19:36', '2026-02-28 10:19:36'),
(13, 'ASUS ROG Ally', 'AMD Z1 Extreme, 7-inch 120Hz touchscreen, Windows 11, 512GB', 39999.00, 14, NULL, 'Gaming', '2026-02-28 10:19:36', '2026-02-28 10:19:36'),
(14, 'PlayStation 5 Slim', 'AMD RDNA 2 GPU, 1TB SSD, 4K 120fps, DualSense controller', 26999.00, 20, NULL, 'Gaming', '2026-02-28 10:19:36', '2026-02-28 10:19:36'),
(15, 'Anker 737 Power Bank', '24,000mAh, 140W charging, dual USB-C, charges laptop + phone', 5999.00, 50, NULL, 'Accessories', '2026-02-28 10:19:36', '2026-02-28 10:19:36'),
(16, 'Logitech MX Master 3S', '8,000 DPI, MagSpeed scroll, quiet clicks, USB-C, multi-device', 6999.00, 45, NULL, 'Accessories', '2026-02-28 10:19:36', '2026-02-28 10:19:36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `email`, `password`, `phone`, `address`, `created_at`, `updated_at`) VALUES
(2, 'AcLaP0dn0GenR69HsC6y+WNVa3lYY3dYVnRJcWRqNUZFd2JJanc9PQ==', 'u4n8c6xDx1K3s6J0yUzO23RJY1F5SHptMEpsUVNqRTdMdlJpM3c9PQ==', '$2y$12$97lMZyrm59LSq17GH3/KWulttjM4saSuk6OhCS3v4Det3nqn241IG', NULL, NULL, '2026-02-28 10:28:43', '2026-02-28 10:28:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `login_logs`
--
ALTER TABLE `login_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `login_logs`
--
ALTER TABLE `login_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
