<?php
// user/register.php
session_start();
require_once '../includes/config.php';
require_once '../includes/db.php';

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$success = '';
$csrf = generate_csrf();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request.';
    } else {
        $fullname = sanitize($_POST['fullname'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm_pw = $_POST['confirm_password'] ?? '';

        if (empty($fullname) || empty($email) || empty($password)) {
            $error = 'Full name, email, and password are required.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email address.';
        } elseif (!validate_password($password)) {
            $error = 'Password must be at least 8 characters with letters and numbers.';
        } elseif ($password !== $confirm_pw) {
            $error = 'Passwords do not match.';
        } else {
            $db = get_db();
            $all = $db->query("SELECT email FROM users")->fetch_all(MYSQLI_ASSOC);
            $email_exists = false;
            foreach ($all as $row) {
                if (decrypt_data($row['email']) === $email) {
                    $email_exists = true;
                    break;
                }
            }
            if ($email_exists) {
                $error = 'Email already registered.';
            } else {
                $enc_name = encrypt_data($fullname);
                $enc_email = encrypt_data($email);
                $hashed_pw = hash_password($password);
                $stmt = $db->prepare("INSERT INTO users (fullname, email, password) VALUES (?,?,?)");
                $stmt->bind_param('sss', $enc_name, $enc_email, $hashed_pw);
                if ($stmt->execute()) {
                    $success = 'Registration successful! You can now login.';
                } else {
                    $error = 'Registration failed. Please try again.';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register — JoltAJ</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        .password-wrapper {
            position: relative;
        }

        .password-wrapper input {
            padding-right: 44px;
        }

        .pw-toggle {
            position: absolute;
            right: 13px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            color: var(--text-light);
            font-size: 15px;
            padding: 0;
            line-height: 1;
        }

        .pw-toggle:hover {
            color: var(--primary);
        }
    </style>
</head>

<body>
    <div class="auth-wrapper">
        <div class="auth-card" style="max-width:420px">
            <div class="auth-logo">
                <span class="icon">🛍️</span>
                <h1>JoltAJ</h1>
                <p>Join the gadget revolution ⚡</p>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-error"><i class="fa fa-circle-exclamation"></i> <?= $error ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success"><i class="fa fa-circle-check"></i> <?= $success ?></div>
            <?php endif; ?>

            <?php if (!$success): ?>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= $csrf ?>">

                    <div class="form-group">
                        <label>Full Name *</label>
                        <input type="text" name="fullname" placeholder="Juan dela Cruz" required>
                    </div>

                    <div class="form-group">
                        <label>Email *</label>
                        <input type="email" name="email" placeholder="juan@email.com" required>
                    </div>

                    <div class="form-group">
                        <label>Password * <span style="font-weight:400;font-size:11px;color:var(--text-light)">(min. 8
                                chars, alphanumeric)</span></label>
                        <div class="password-wrapper">
                            <input type="password" name="password" id="pw1" placeholder="e.g. MyPass12" required
                                minlength="8">
                            <button type="button" class="pw-toggle" onclick="togglePw('pw1','ico1')">
                                <i class="fa fa-eye" id="ico1"></i>
                            </button>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Confirm Password *</label>
                        <div class="password-wrapper">
                            <input type="password" name="confirm_password" id="pw2" placeholder="Repeat your password"
                                required>
                            <button type="button" class="pw-toggle" onclick="togglePw('pw2','ico2')">
                                <i class="fa fa-eye" id="ico2"></i>
                            </button>
                        </div>
                    </div>


                    <button type="submit" class="btn btn-primary btn-block">
                        <i class="fa fa-user-plus"></i> Create Account
                    </button>
                </form>
            <?php endif; ?>

            <div class="auth-links">Already have an account? <a href="login.php">Login here</a></div>
        </div>
    </div>
    <script>
        function togglePw(inputId, iconId) {
            const input = document.getElementById(inputId);
            const icon = document.getElementById(iconId);
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        }
    </script>
</body>

</html>