<?php
// user/profile.php
require_once '../includes/user_auth.php';
$db = get_db();
$error = ''; $success = '';
$csrf    = generate_csrf();
$user_id = $_SESSION['user_id'];

$stmt = $db->prepare("SELECT * FROM users WHERE id=?");
$stmt->bind_param('i', $user_id); $stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Guard: session user_id has no matching DB record
if (!$user) {
    session_destroy();
    header('Location: login.php?msg=session_expired');
    exit;
}

$user['_name']    = decrypt_data($user['fullname'] ?? '');
$user['_email']   = decrypt_data($user['email']    ?? '');
$user['_phone']   = decrypt_data($user['phone']    ?? '');
$user['_address'] = decrypt_data($user['address']  ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) { $error = 'Invalid request.'; }
    else {
        $action = $_POST['action'] ?? 'update';

        if ($action === 'update') {
            $fullname   = sanitize($_POST['fullname'] ?? '');
            $email      = sanitize($_POST['email'] ?? '');
            $phone      = sanitize($_POST['phone'] ?? '');
            $address    = sanitize($_POST['address'] ?? '');
            $password   = $_POST['password'] ?? '';
            $confirm_pw = $_POST['confirm_password'] ?? '';
            $current_pw = $_POST['current_password'] ?? '';

            if (empty($fullname) || empty($email)) { $error = 'Name and email are required.'; }
            elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $error = 'Invalid email.'; }
            else {
                if (!empty($password)) {
                    if (!verify_password($current_pw, $user['password'])) { $error = 'Current password is incorrect.'; }
                    elseif (!validate_password($password)) { $error = 'New password: 8+ alphanumeric chars.'; }
                    elseif ($password !== $confirm_pw)     { $error = 'New passwords do not match.'; }
                }
                if (!$error) {
                    $all = $db->query("SELECT id, email FROM users")->fetch_all(MYSQLI_ASSOC);
                    foreach ($all as $r) {
                        if ((int)$r['id'] !== $user_id && decrypt_data($r['email']) === $email) { $error = 'Email already used.'; break; }
                    }
                }
                if (!$error) {
                    $en = encrypt_data($fullname); $ee = encrypt_data($email);
                    $ep = encrypt_data($phone);    $ea = encrypt_data($address);
                    if (!empty($password)) {
                        $hp   = hash_password($password);
                        $stmt = $db->prepare("UPDATE users SET fullname=?,email=?,phone=?,address=?,password=? WHERE id=?");
                        $stmt->bind_param('sssssi', $en, $ee, $ep, $ea, $hp, $user_id);
                    } else {
                        $stmt = $db->prepare("UPDATE users SET fullname=?,email=?,phone=?,address=? WHERE id=?");
                        $stmt->bind_param('ssssi', $en, $ee, $ep, $ea, $user_id);
                    }
                    if ($stmt->execute()) {
                        $_SESSION['user_name'] = $fullname;
                        $success = 'Profile updated successfully!';
                        $user['_name'] = $fullname; $user['_email'] = $email;
                        $user['_phone'] = $phone;   $user['_address'] = $address;
                    } else { $error = 'Update failed.'; }
                }
            }
        }

        if ($action === 'delete') {
            $pw = $_POST['delete_password'] ?? '';
            if (!verify_password($pw, $user['password'])) { $error = 'Incorrect password.'; }
            else {
                $stmt = $db->prepare("DELETE FROM users WHERE id=?");
                $stmt->bind_param('i', $user_id); $stmt->execute();
                session_destroy(); header('Location: login.php'); exit;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Profile — JoltAJ</title>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="dashboard">
<?php require_once '../includes/user_sidebar.php'; ?>
<div class="main-content">
    <div class="topbar">
        <div class="topbar-left">
            <button class="hamburger" id="hamburgerBtn" onclick="toggleSidebar()" aria-label="Toggle menu">
                <span></span><span></span><span></span>
            </button>
            <div class="topbar-title">👤 My Profile</div>
        </div>
        <div class="topbar-user">
            <div class="avatar"><?= strtoupper(substr($_SESSION['user_name'],0,1)) ?></div>
            <span><?= sanitize($_SESSION['user_name']) ?></span>
        </div>
    </div>
    <div class="page-content">
        <?php if ($error): ?><div class="alert alert-error"><i class="fa fa-circle-exclamation"></i> <?= $error ?></div><?php endif; ?>
        <?php if ($success): ?><div class="alert alert-success"><i class="fa fa-circle-check"></i> <?= $success ?></div><?php endif; ?>

        <div class="profile-header">
            <div class="profile-avatar"><?= strtoupper(substr($user['_name'],0,1)) ?></div>
            <div>
                <div class="profile-name"><?= sanitize($user['_name']) ?></div>
                <div class="profile-email"><i class="fa fa-envelope"></i> <?= sanitize($user['_email']) ?></div>
                <div style="opacity:.7;font-size:12px;margin-top:4px">Member since <?= date('F Y', strtotime($user['created_at'])) ?></div>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><div class="card-title"><i class="fa fa-pen"></i> Update Profile</div></div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                    <input type="hidden" name="action" value="update">
                    <div class="form-row">
                        <div class="form-group"><label>Full Name *</label><input type="text" name="fullname" value="<?= sanitize($user['_name']) ?>" required></div>
                        <div class="form-group"><label>Email *</label><input type="email" name="email" value="<?= sanitize($user['_email']) ?>" required></div>
                    </div>
                    <div class="form-row">
                        <div class="form-group"><label>Phone</label><input type="text" name="phone" value="<?= sanitize($user['_phone']) ?>"></div>
                        <div class="form-group"><label>Address</label><input type="text" name="address" value="<?= sanitize($user['_address']) ?>"></div>
                    </div>

                    <hr style="border:none;border-top:1px solid var(--border);margin:18px 0;">
                    <p style="font-weight:700;margin-bottom:12px;font-size:13.5px"><i class="fa fa-lock"></i> Change Password <span style="font-weight:400;color:var(--text-light);font-size:12px">(leave blank to keep current)</span></p>
                    <div class="form-row">
                        <div class="form-group"><label>Current Password</label>
                            <div class="password-wrapper">
                                <input type="password" name="current_password" id="cp_cur" placeholder="Current password">
                                <button type="button" class="pw-toggle" onclick="togglePw('cp_cur','ico_cur')"><i class="fa fa-eye" id="ico_cur"></i></button>
                            </div>
                        </div>
                        <div class="form-group"><label>New Password (8+ alphanumeric)</label>
                            <div class="password-wrapper">
                                <input type="password" name="password" id="cp_new" minlength="8">
                                <button type="button" class="pw-toggle" onclick="togglePw('cp_new','ico_new')"><i class="fa fa-eye" id="ico_new"></i></button>
                            </div>
                        </div>
                    </div>
                    <div class="form-group"><label>Confirm New Password</label>
                        <div class="password-wrapper">
                            <input type="password" name="confirm_password" id="cp_con">
                            <button type="button" class="pw-toggle" onclick="togglePw('cp_con','ico_con')"><i class="fa fa-eye" id="ico_con"></i></button>
                        </div>
                    </div>
                    <p style="font-size:12px;color:var(--text-light);margin-bottom:14px"><i class="fa fa-shield"></i> Data is encrypted. Password is hashed.</p>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-floppy-disk"></i> Save Changes</button>
                </form>
            </div>
        </div>

        <div class="card" style="border-color:#fecaca;">
            <div class="card-header" style="background:#fef2f2;">
                <div class="card-title" style="color:var(--danger)"><i class="fa fa-triangle-exclamation"></i> Danger Zone</div>
            </div>
            <div class="card-body">
                <p style="color:var(--text-light);margin-bottom:14px;font-size:13.5px">Permanently delete your account. This action cannot be undone.</p>
                <button class="btn btn-danger btn-sm" onclick="openModal('deleteModal')"><i class="fa fa-trash"></i> Delete My Account</button>
            </div>
        </div>
    </div>
</div>
</div>

<!-- Delete Account Modal -->
<div class="modal-overlay" id="deleteModal">
<div class="modal">
    <div class="modal-header">
        <div class="modal-title" style="color:var(--danger)"><i class="fa fa-trash"></i> Delete Account</div>
        <button class="modal-close" onclick="closeModal('deleteModal')"><i class="fa fa-xmark"></i></button>
    </div>
    <form method="POST">
    <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
        <input type="hidden" name="action" value="delete">
        <div class="alert alert-error">This will permanently delete all your data and cannot be undone.</div>
        <div class="form-group"><label>Enter your password to confirm</label>
            <div class="password-wrapper">
                <input type="password" name="delete_password" id="dp_pw" required placeholder="Your current password">
                <button type="button" class="pw-toggle" onclick="togglePw('dp_pw','dp_ico')"><i class="fa fa-eye" id="dp_ico"></i></button>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('deleteModal')">Cancel</button>
        <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i> Yes, Delete</button>
    </div>
    </form>
</div>
</div>

<script src="../assets/js/sidebar.js"></script>
<script>
function openModal(id)  { document.getElementById(id).classList.add('active'); }
function closeModal(id) { document.getElementById(id).classList.remove('active'); }
function togglePw(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon  = document.getElementById(iconId);
    input.type === 'password'
        ? (input.type = 'text',     icon.classList.replace('fa-eye','fa-eye-slash'))
        : (input.type = 'password', icon.classList.replace('fa-eye-slash','fa-eye'));
}
window.addEventListener('click', e => {
    if (e.target.classList.contains('modal-overlay')) e.target.classList.remove('active');
});
</script>
</body>
</html>
