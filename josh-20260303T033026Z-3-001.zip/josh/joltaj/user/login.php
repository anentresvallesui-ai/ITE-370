<?php
// user/login.php
session_start();
require_once '../includes/config.php';
require_once '../includes/db.php';

if (isset($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }

$error = '';
$csrf  = generate_csrf();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request.';
    } else {
        $email    = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            $error = 'Please fill in all fields.';
        } else {
            $db  = get_db();
            $all = $db->query("SELECT id, fullname, email, password FROM users")->fetch_all(MYSQLI_ASSOC);
            $found = null;
            foreach ($all as $u) {
                if (decrypt_data($u['email']) === $email) { $found = $u; break; }
            }
            if ($found && verify_password($password, $found['password'])) {
                $_SESSION['user_id']   = $found['id'];
                $_SESSION['user_name'] = decrypt_data($found['fullname']);
                header('Location: dashboard.php');
                exit;
            } else {
                $error = 'Invalid email or password.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — JoltAJ</title>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
.password-wrapper { position: relative; }
.password-wrapper input { padding-right: 44px; }
.pw-toggle {
    position: absolute; right: 13px; top: 50%; transform: translateY(-50%);
    background: none; border: none; cursor: pointer; color: var(--text-light);
    font-size: 15px; padding: 0; line-height: 1;
}
.pw-toggle:hover { color: var(--primary); }
</style>
</head>
<body>
<div class="auth-wrapper">
<div class="auth-card">
    <div class="auth-logo">
        <span class="icon">🛍️</span>
        <h1>JoltAJ</h1>
        <p>Your gadget store awaits! ⚡</p>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-error"><i class="fa fa-circle-exclamation"></i> <?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= $csrf ?>">

        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" placeholder="your@email.com" required>
        </div>

        <div class="form-group">
            <label>Password</label>
            <div class="password-wrapper">
                <input type="password" name="password" id="pw" placeholder="Your password" required>
                <button type="button" class="pw-toggle" onclick="togglePw('pw','ico')">
                    <i class="fa fa-eye" id="ico"></i>
                </button>
            </div>
        </div>

        <button type="submit" class="btn btn-primary btn-block">
            <i class="fa fa-right-to-bracket"></i> Login
        </button>
    </form>

    <div class="auth-links">Don't have an account? <a href="register.php">Register here</a></div>
</div>
</div>
<script>
function togglePw(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon  = document.getElementById(iconId);
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.replace('fa-eye-slash', 'fa-eye');
    }
}
</script>
</body>
</html>
