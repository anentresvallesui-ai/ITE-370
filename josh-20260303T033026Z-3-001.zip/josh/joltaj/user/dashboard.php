<?php
// user/dashboard.php
require_once '../includes/user_auth.php';
$db = get_db();
$products       = $db->query("SELECT * FROM products ORDER BY created_at DESC LIMIT 6")->fetch_all(MYSQLI_ASSOC);
$products_total = $db->query("SELECT COUNT(*) as c FROM products")->fetch_assoc()['c'];
$icons = ['Smartphones'=>'📱','Laptops'=>'💻','Tablets'=>'📟','Audio'=>'🎧','Wearables'=>'⌚','Cameras'=>'📷','Drones'=>'🚁','Gaming'=>'🎮','Accessories'=>'🔌','Smart Home'=>'🏠','Other'=>'📦'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard — JoltAJ</title>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="dashboard">
<?php require_once '../includes/user_sidebar.php'; ?>
<div class="main-content">
    <div class="topbar">
        <div class="topbar-left">
            <button class="hamburger" id="hamburgerBtn" onclick="toggleSidebar()" aria-label="Toggle menu">
                <span></span><span></span><span></span>
            </button>
            <div class="topbar-title">🏠 Home</div>
        </div>
        <div class="topbar-user">
            <div class="avatar"><?= strtoupper(substr($_SESSION['user_name'], 0, 1)) ?></div>
            <span><?= sanitize($_SESSION['user_name']) ?></span>
        </div>
    </div>

    <div class="page-content">
        <div style="background:linear-gradient(135deg,#7c3aed,#0ea5e9);color:#fff;padding:24px 20px;border-radius:14px;margin-bottom:20px;">
            <h2 style="font-size:20px;margin-bottom:4px">Hello, <?= sanitize($_SESSION['user_name']) ?>! ⚡</h2>
            <p style="opacity:.85;font-size:14px">Discover the latest gadgets — phones, laptops, wearables & more.</p>
        </div>

        <div class="card">
            <div class="card-header">
                <div class="card-title">🔥 Featured Products</div>
                <a href="products.php" class="btn btn-primary btn-sm"><i class="fa fa-store"></i> View All (<?= $products_total ?>)</a>
            </div>
            <div class="card-body">
                <?php if (empty($products)): ?>
                <div class="empty-state"><span class="empty-icon">🛒</span>No products yet. Check back later!</div>
                <?php else: ?>
                <div class="products-grid">
                <?php foreach ($products as $p): $icon = $icons[$p['category']] ?? '📦'; ?>
                <div class="product-card">
                    <div class="product-img"><?= $icon ?></div>
                    <div class="product-info">
                        <div class="product-name"><?= sanitize($p['name']) ?></div>
                        <div class="product-desc"><?= sanitize($p['description']) ?></div>
                        <div class="product-footer">
                            <div class="product-price">₱<?= number_format($p['price'], 2) ?></div>
                            <div class="product-stock"><?= $p['stock'] > 0 ? "Stock: {$p['stock']}" : '<span style="color:#ef4444">Out of stock</span>' ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
</div>
<script src="../assets/js/sidebar.js"></script>
</body>
</html>
