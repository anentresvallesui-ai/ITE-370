<?php
// user/products.php
require_once '../includes/user_auth.php';
$db = get_db();
$search   = sanitize($_GET['q'] ?? '');
$category = sanitize($_GET['cat'] ?? '');

$where = '1=1'; $params = []; $types = '';
if ($search)   { $where .= ' AND (name LIKE ? OR description LIKE ?)'; $like = "%$search%"; $params[] = $like; $params[] = $like; $types .= 'ss'; }
if ($category) { $where .= ' AND category = ?'; $params[] = $category; $types .= 's'; }

if ($params) {
    $stmt = $db->prepare("SELECT * FROM products WHERE $where ORDER BY created_at DESC");
    $stmt->bind_param($types, ...$params); $stmt->execute();
    $products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} else {
    $products = $db->query("SELECT * FROM products ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
}
$cats  = $db->query("SELECT DISTINCT category FROM products ORDER BY category")->fetch_all(MYSQLI_ASSOC);
$icons = ['Smartphones'=>'📱','Laptops'=>'💻','Tablets'=>'📟','Audio'=>'🎧','Wearables'=>'⌚','Cameras'=>'📷','Drones'=>'🚁','Gaming'=>'🎮','Accessories'=>'🔌','Smart Home'=>'🏠','Other'=>'📦'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Products — JoltAJ</title>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="dashboard">
<?php require_once '../includes/user_sidebar.php'; ?>
<div class="main-content">
    <div class="topbar">
        <div class="topbar-left">
            <button class="hamburger" id="hamburgerBtn" onclick="toggleSidebar()" aria-label="Toggle menu">
                <span></span><span></span><span></span>
            </button>
            <div class="topbar-title">🛒 Browse Products</div>
        </div>
        <div class="topbar-user">
            <div class="avatar"><?= strtoupper(substr($_SESSION['user_name'],0,1)) ?></div>
            <span><?= sanitize($_SESSION['user_name']) ?></span>
        </div>
    </div>
    <div class="page-content">
        <form method="GET" style="display:flex;gap:8px;margin-bottom:18px;flex-wrap:wrap;">
            <input type="text" name="q" placeholder="🔍 Search products…" value="<?= sanitize($search) ?>"
                style="flex:1;min-width:140px;padding:10px 13px;border:2px solid var(--border);border-radius:10px;font-size:13.5px;outline:none;">
            <select name="cat" style="padding:10px 13px;border:2px solid var(--border);border-radius:10px;font-size:13.5px;outline:none;min-width:130px;">
                <option value="">All Categories</option>
                <?php foreach ($cats as $c): ?>
                <option value="<?= $c['category'] ?>" <?= $category === $c['category'] ? 'selected' : '' ?>><?= $c['category'] ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-search"></i> Search</button>
            <?php if ($search || $category): ?><a href="products.php" class="btn btn-secondary btn-sm">Clear</a><?php endif; ?>
        </form>

        <p style="color:var(--text-light);font-size:13px;margin-bottom:14px">
            Showing <strong><?= count($products) ?></strong> product(s)
        </p>

        <?php if (empty($products)): ?>
        <div class="empty-state"><span class="empty-icon">🔍</span>No products found.</div>
        <?php else: ?>
        <div class="products-grid">
        <?php foreach ($products as $p): $icon = $icons[$p['category']] ?? '📦'; ?>
        <div class="product-card">
            <div class="product-img"><?= $icon ?></div>
            <div class="product-info">
                <div class="product-name"><?= sanitize($p['name']) ?></div>
                <div class="product-desc"><?= sanitize($p['description']) ?: 'No description.' ?></div>
                <div style="margin-bottom:8px"><span class="badge badge-success"><?= sanitize($p['category']) ?></span></div>
                <div class="product-footer">
                    <div class="product-price">₱<?= number_format($p['price'], 2) ?></div>
                    <div class="product-stock"><?= $p['stock'] > 0 ? "Stock: {$p['stock']}" : '<span style="color:#ef4444">Out of stock</span>' ?></div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>
</div>
<script src="../assets/js/sidebar.js"></script>
</body>
</html>
