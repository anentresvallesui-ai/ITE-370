<?php // includes/admin_sidebar.php ?>

<!-- Backdrop overlay (mobile/tablet) -->
<div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>

<nav class="sidebar" id="sidebar">
    <div class="sidebar-brand">
        <div class="brand-info">
            <div class="brand-name">⚡ JoltAJ</div>
            <div class="brand-sub">Admin Panel</div>
        </div>
        <button class="sidebar-close" onclick="closeSidebar()" title="Close menu">
            <i class="fa fa-xmark"></i>
        </button>
    </div>

    <div class="sidebar-nav">
        <div class="nav-section">Main</div>
        <div class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>">
            <a href="dashboard.php" onclick="autoClose()">
                <span class="nav-icon">📊</span> Dashboard
            </a>
        </div>

        <div class="nav-section">Management</div>
        <div class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : '' ?>">
            <a href="users.php" onclick="autoClose()">
                <span class="nav-icon">👥</span> Users
            </a>
        </div>
        <div class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'products.php' ? 'active' : '' ?>">
            <a href="products.php" onclick="autoClose()">
                <span class="nav-icon">🛒</span> Products
            </a>
        </div>

        <div class="nav-section">Account</div>
        <div class="nav-item">
            <a href="#" onclick="event.preventDefault(); openLogoutModal()">
                <span class="nav-icon">🚪</span> Logout
            </a>
        </div>
    </div>
</nav>

<!-- Logout Confirmation Modal -->
<div class="modal-overlay" id="logoutModal">
    <div class="modal" style="max-width:380px">
        <div class="modal-header">
            <div class="modal-title">🚪 Confirm Logout</div>
        </div>
        <div class="modal-body" style="text-align:center;padding:28px 24px">
            <div style="font-size:48px;margin-bottom:12px">👋</div>
            <p style="font-size:15px;font-weight:600;color:#1e293b;margin-bottom:6px">Are you sure you want to logout?</p>
            <p style="font-size:13px;color:#64748b">You will be redirected to the admin login page.</p>
        </div>
        <div class="modal-footer" style="justify-content:center;gap:12px">
            <button type="button" class="btn btn-secondary" onclick="closeLogoutModal()">
                <i class="fa fa-xmark"></i> Cancel
            </button>
            <a href="logout.php" class="btn btn-danger">
                <i class="fa fa-right-from-bracket"></i> Yes, Logout
            </a>
        </div>
    </div>
</div>

<script>
function openLogoutModal()  { document.getElementById('logoutModal').classList.add('active'); }
function closeLogoutModal() { document.getElementById('logoutModal').classList.remove('active'); }
window.addEventListener('click', function(e) {
    if (e.target.id === 'logoutModal') closeLogoutModal();
});
</script>
