<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/db.php';
if (isset($_SESSION['admin_id'])) { header('Location: dashboard.php'); exit; }

$error=''; $csrf=generate_csrf();

if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!verify_csrf($_POST['csrf_token']??'')) { $error='Invalid request.'; }
    else {
        $username=sanitize($_POST['username']??''); $password=$_POST['password']??'';
        if (empty($username)||empty($password)) { $error='Please fill in all fields.'; }
        else {
            $db=get_db();
            $stmt=$db->prepare("SELECT id, username, email, password FROM admins WHERE username=? LIMIT 1");
            $stmt->bind_param('s',$username);
            $stmt->execute();
            $result=$stmt->get_result();
            $admin=$result->fetch_assoc();
            if ($admin && verify_password($password,$admin['password'])) {
                $_SESSION['admin_id']=$admin['id'];
                $_SESSION['admin_username']=$admin['username'];
                $ip=$_SERVER['REMOTE_ADDR']??'unknown';
                $log=$db->prepare("INSERT INTO login_logs (user_type,user_id,ip_address) VALUES ('admin',?,?)");
                $log->bind_param('is',$admin['id'],$ip);
                $log->execute();
                header('Location: dashboard.php'); exit;
            } else { $error='Invalid username or password.'; }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login — ThreadVibe</title>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
.admin-badge {
    display: inline-flex; align-items: center; gap: 6px;
    background: rgba(201,168,76,0.12); border: 1px solid rgba(201,168,76,0.3);
    color: #c9a84c; font-size: 11px; letter-spacing: 2px;
    text-transform: uppercase; padding: 5px 14px; border-radius: 20px;
    margin-bottom: 28px;
}
</style>
</head>
<body>
<div class="auth-wrapper">
    <div class="auth-visual">
        <div class="auth-visual-text">
            <div class="auth-visual-logo">Thread<span>Vibe</span></div>
            <div class="auth-visual-tagline">Admin Control Panel</div>
            <div class="auth-visual-quote">Style is a way to say who you are without having to speak.</div>
        </div>
        <div class="auth-decorlines">
            <?php for($i=0;$i<5;$i++): ?><span style="--i:<?= $i ?>"></span><?php endfor; ?>
        </div>
    </div>
    <div class="auth-form-side">
        <div class="auth-card">
            <div class="auth-card-header">
                <div class="admin-badge"><i class="fa fa-shield-halved"></i> Administrator</div>
                <h2>Admin Sign In</h2>
                <p>Access the ThreadVibe dashboard</p>
            </div>
            <?php if($error): ?><div class="alert alert-error"><i class="fa fa-circle-exclamation"></i> <?= htmlspecialchars($error) ?></div><?php endif; ?>
            <form method="POST" autocomplete="off">
                <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                <div class="form-group">
                    <label><i class="fa fa-user" style="margin-right:6px;color:#c9a84c;font-size:12px"></i>Username</label>
                    <input type="text" name="username" placeholder="admin username" autocomplete="username" required>
                </div>
                <div class="form-group">
                    <label><i class="fa fa-lock" style="margin-right:6px;color:#c9a84c;font-size:12px"></i>Password</label>
                    <div class="password-wrapper">
                        <input type="password" name="password" id="pw" placeholder="••••••••" autocomplete="current-password" required>
                        <button type="button" class="pw-toggle" onclick="togglePw('pw','ico')"><i class="fa fa-eye" id="ico"></i></button>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-block" style="margin-top:8px">
                    <i class="fa fa-arrow-right-to-bracket"></i> Sign In to Admin
                </button>
            </form>
            <div class="auth-links" style="margin-top:24px;text-align:center">
                <a href="../user/login.php" style="color:#5a5550;font-size:12px"><i class="fa fa-arrow-left"></i> Back to User Login</a>
            </div>
        </div>
    </div>
</div>
<script>
function togglePw(i,c){const el=document.getElementById(i),ic=document.getElementById(c);el.type==='password'?(el.type='text',ic.classList.replace('fa-eye','fa-eye-slash')):(el.type='password',ic.classList.replace('fa-eye-slash','fa-eye'));}
</script>
</body>
</html>