<?php
require_once '../includes/admin_auth.php';
$db=get_db(); $error=''; $success=''; $csrf=generate_csrf();

if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!verify_csrf($_POST['csrf_token']??'')) { $error='Invalid CSRF.'; }
    else {
        $action=$_POST['action']??'';
        if ($action==='create') {
            $nm=sanitize($_POST['name']??''); $dc=sanitize($_POST['description']??'');
            $pr=(float)($_POST['price']??0); $st=(int)($_POST['stock']??0); $ct=sanitize($_POST['category']??'');
            if (empty($nm)||$pr<=0) { $error='Name and valid price required.'; }
            else { $stmt=$db->prepare("INSERT INTO products (name,description,price,stock,category) VALUES (?,?,?,?,?)"); $stmt->bind_param('ssdis',$nm,$dc,$pr,$st,$ct); if($stmt->execute()) $success='Product added.'; else $error='Error.'; }
        }
        if ($action==='update') {
            $id=(int)($_POST['product_id']??0); $nm=sanitize($_POST['name']??''); $dc=sanitize($_POST['description']??'');
            $pr=(float)($_POST['price']??0); $st=(int)($_POST['stock']??0); $ct=sanitize($_POST['category']??'');
            if ($id<=0||empty($nm)||$pr<=0) { $error='Invalid data.'; }
            else { $stmt=$db->prepare("UPDATE products SET name=?,description=?,price=?,stock=?,category=? WHERE id=?"); $stmt->bind_param('ssdisi',$nm,$dc,$pr,$st,$ct,$id); if($stmt->execute()) $success='Updated.'; else $error='Failed.'; }
        }
        if ($action==='delete') {
            $id=(int)($_POST['product_id']??0);
            if($id>0){ $stmt=$db->prepare("DELETE FROM products WHERE id=?"); $stmt->bind_param('i',$id); if($stmt->execute()) $success='Deleted.'; else $error='Failed.'; }
        }
    }
}
$search=sanitize($_GET['q']??'');
if ($search){ $stmt=$db->prepare("SELECT * FROM products WHERE name LIKE ? OR category LIKE ? ORDER BY created_at DESC"); $like="%$search%"; $stmt->bind_param('ss',$like,$like); $stmt->execute(); $products=$stmt->get_result()->fetch_all(MYSQLI_ASSOC); }
else { $products=$db->query("SELECT * FROM products ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC); }
$categories=['Tops','Bottoms','Dresses','Outerwear','Sets','Swimwear','Activewear','Accessories','Footwear','Other'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Products — ThreadVibe Admin</title>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="dashboard">
<?php require_once '../includes/admin_sidebar.php'; ?>
<div class="main-content">
    <div class="topbar">
        <div class="topbar-left">
            <button class="hamburger" id="hamburgerBtn" onclick="toggleSidebar()"><span></span><span></span><span></span></button>
            <div class="topbar-title">Products</div>
        </div>
        <div class="topbar-right">
            <span class="topbar-user-name"><?= sanitize($_SESSION['admin_username']) ?></span>
            <div class="avatar"><?= strtoupper(substr($_SESSION['admin_username'],0,1)) ?></div>
        </div>
    </div>
    <div class="page-content">
        <?php if($error): ?><div class="alert alert-error"><i class="fa fa-circle-exclamation"></i> <?= $error ?></div><?php endif; ?>
        <?php if($success): ?><div class="alert alert-success"><i class="fa fa-circle-check"></i> <?= $success ?></div><?php endif; ?>
        <div class="card">
            <div class="card-header">
                <div class="card-title">All Products (<?= count($products) ?>)</div>
                <button class="btn btn-primary btn-sm" onclick="openModal('createModal')"><i class="fa fa-plus"></i> Add Product</button>
            </div>
            <div class="card-body" style="padding-bottom:0">
                <form method="GET" class="search-bar">
                    <input type="text" name="q" placeholder="Search products…" value="<?= sanitize($search) ?>">
                    <button type="submit" class="btn btn-outline btn-sm"><i class="fa fa-search"></i></button>
                    <?php if($search): ?><a href="products.php" class="btn btn-ghost btn-sm">Clear</a><?php endif; ?>
                </form>
            </div>
            <div class="table-responsive">
                <table>
                    <thead><tr><th>#</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Actions</th></tr></thead>
                    <tbody>
                    <?php if(empty($products)): ?>
                    <tr><td colspan="6"><div class="empty-state"><span class="empty-icon"><i class="fa fa-shirt"></i></span><p>No products yet.</p></div></td></tr>
                    <?php else: foreach($products as $p): ?>
                    <tr>
                        <td><?= $p['id'] ?></td>
                        <td style="color:var(--text);font-weight:500"><?= sanitize($p['name']) ?></td>
                        <td><span class="badge badge-gold"><?= sanitize($p['category']) ?></span></td>
                        <td class="price-tag">₱<?= number_format($p['price'],2) ?></td>
                        <td><?= $p['stock']<=5?"<span class='badge badge-danger'>{$p['stock']}</span>":"<span class='badge badge-success'>{$p['stock']}</span>" ?></td>
                        <td style="white-space:nowrap">
                            <button class="btn btn-warning btn-sm" onclick="openEdit(<?= htmlspecialchars(json_encode($p)) ?>)"><i class="fa fa-pen"></i></button>
                            <button class="btn btn-danger btn-sm" onclick="confirmDelete(<?= $p['id'] ?>,'<?= sanitize($p['name']) ?>')"><i class="fa fa-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
<!-- Create -->
<div class="modal-overlay" id="createModal"><div class="modal">
    <div class="modal-header"><div class="modal-title">Add Product</div><button class="modal-close" onclick="closeModal('createModal')"><i class="fa fa-xmark"></i></button></div>
    <form method="POST"><div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= $csrf ?>"><input type="hidden" name="action" value="create">
        <div class="form-row">
            <div class="form-group"><label>Name *</label><input type="text" name="name" required></div>
            <div class="form-group"><label>Category</label><select name="category"><?php foreach($categories as $c): ?><option><?= $c ?></option><?php endforeach; ?></select></div>
        </div>
        <div class="form-group"><label>Description</label><textarea name="description" rows="3"></textarea></div>
        <div class="form-row">
            <div class="form-group"><label>Price (₱) *</label><input type="number" name="price" step="0.01" min="0" required></div>
            <div class="form-group"><label>Stock *</label><input type="number" name="stock" min="0" value="0" required></div>
        </div>
    </div>
    <div class="modal-footer"><button type="button" class="btn btn-ghost btn-sm" onclick="closeModal('createModal')">Cancel</button><button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-check"></i> Add</button></div>
    </form>
</div></div>
<!-- Edit -->
<div class="modal-overlay" id="editModal"><div class="modal">
    <div class="modal-header"><div class="modal-title">Edit Product</div><button class="modal-close" onclick="closeModal('editModal')"><i class="fa fa-xmark"></i></button></div>
    <form method="POST"><div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= $csrf ?>"><input type="hidden" name="action" value="update"><input type="hidden" name="product_id" id="edit_id">
        <div class="form-row">
            <div class="form-group"><label>Name *</label><input type="text" name="name" id="edit_name" required></div>
            <div class="form-group"><label>Category</label><select name="category" id="edit_cat"><?php foreach($categories as $c): ?><option><?= $c ?></option><?php endforeach; ?></select></div>
        </div>
        <div class="form-group"><label>Description</label><textarea name="description" id="edit_desc" rows="3"></textarea></div>
        <div class="form-row">
            <div class="form-group"><label>Price (₱) *</label><input type="number" name="price" id="edit_price" step="0.01" min="0" required></div>
            <div class="form-group"><label>Stock *</label><input type="number" name="stock" id="edit_stock" min="0" required></div>
        </div>
    </div>
    <div class="modal-footer"><button type="button" class="btn btn-ghost btn-sm" onclick="closeModal('editModal')">Cancel</button><button type="submit" class="btn btn-warning btn-sm"><i class="fa fa-floppy-disk"></i> Update</button></div>
    </form>
</div></div>
<!-- Delete -->
<div class="modal-overlay" id="deleteModal"><div class="modal" style="max-width:380px">
    <div class="modal-header"><div class="modal-title">Delete Product</div></div>
    <form method="POST"><div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= $csrf ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="product_id" id="del_id">
        <p style="color:var(--text-muted)">Delete <strong id="del_name" style="color:var(--text)"></strong>? This cannot be undone.</p>
    </div>
    <div class="modal-footer"><button type="button" class="btn btn-ghost btn-sm" onclick="closeModal('deleteModal')">Cancel</button><button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Delete</button></div>
    </form>
</div></div>
<script src="../assets/js/sidebar.js"></script>
<script>
function openModal(id){document.getElementById(id).classList.add('active');}
function closeModal(id){document.getElementById(id).classList.remove('active');}
function openEdit(p){document.getElementById('edit_id').value=p.id;document.getElementById('edit_name').value=p.name;document.getElementById('edit_cat').value=p.category;document.getElementById('edit_desc').value=p.description;document.getElementById('edit_price').value=p.price;document.getElementById('edit_stock').value=p.stock;openModal('editModal');}
function confirmDelete(id,name){document.getElementById('del_id').value=id;document.getElementById('del_name').textContent=name;openModal('deleteModal');}
window.addEventListener('click',e=>{if(e.target.classList.contains('modal-overlay'))e.target.classList.remove('active');});
</script>
</body>
</html>
