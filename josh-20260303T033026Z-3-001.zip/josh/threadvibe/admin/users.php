<?php
require_once '../includes/admin_auth.php';
$db = get_db(); $error=''; $success=''; $csrf=generate_csrf();

if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!verify_csrf($_POST['csrf_token']??'')) { $error='Invalid CSRF token.'; }
    else {
        $action=$_POST['action']??'';
        if ($action==='create') {
            $fn=sanitize($_POST['fullname']??''); $em=sanitize($_POST['email']??'');
            $ph=sanitize($_POST['phone']??'');   $ad=sanitize($_POST['address']??'');
            $pw=$_POST['password']??'';
            if (empty($fn)||empty($em)||empty($pw)) { $error='Name, email and password required.'; }
            elseif (!filter_var($em,FILTER_VALIDATE_EMAIL)) { $error='Invalid email.'; }
            elseif (!validate_password($pw)) { $error='Password: 8+ alphanumeric characters.'; }
            else {
                $all=$db->query("SELECT email FROM users")->fetch_all(MYSQLI_ASSOC);
                $ex=false; foreach($all as $r){if(decrypt_data($r['email'])===$em){$ex=true;break;}}
                if ($ex) { $error='Email already exists.'; }
                else {
                    $stmt=$db->prepare("INSERT INTO users (fullname,email,phone,address,password) VALUES (?,?,?,?,?)");
                    $a=encrypt_data($fn);$b=encrypt_data($em);$c=encrypt_data($ph);$d=encrypt_data($ad);$e=hash_password($pw);
                    $stmt->bind_param('sssss',$a,$b,$c,$d,$e);
                    if($stmt->execute()) $success='Customer created.'; else $error='Database error.';
                }
            }
        }
        if ($action==='update') {
            $id=(int)($_POST['user_id']??0); $fn=sanitize($_POST['fullname']??''); $em=sanitize($_POST['email']??'');
            $ph=sanitize($_POST['phone']??''); $ad=sanitize($_POST['address']??''); $pw=$_POST['password']??'';
            if ($id<=0||empty($fn)||empty($em)) { $error='Invalid data.'; }
            elseif (!filter_var($em,FILTER_VALIDATE_EMAIL)) { $error='Invalid email.'; }
            else {
                $all=$db->query("SELECT id,email FROM users")->fetch_all(MYSQLI_ASSOC);
                $ex=false; foreach($all as $r){if((int)$r['id']!==$id&&decrypt_data($r['email'])===$em){$ex=true;break;}}
                if ($ex) { $error='Email already used.'; }
                else {
                    $a=encrypt_data($fn);$b=encrypt_data($em);$c=encrypt_data($ph);$d=encrypt_data($ad);
                    if (!empty($pw)) {
                        if (!validate_password($pw)) { $error='Password: 8+ alphanumeric.'; }
                        else { $e=hash_password($pw); $stmt=$db->prepare("UPDATE users SET fullname=?,email=?,phone=?,address=?,password=? WHERE id=?"); $stmt->bind_param('sssssi',$a,$b,$c,$d,$e,$id); if($stmt->execute()) $success='Updated.'; else $error='Failed.'; }
                    } else { $stmt=$db->prepare("UPDATE users SET fullname=?,email=?,phone=?,address=? WHERE id=?"); $stmt->bind_param('ssssi',$a,$b,$c,$d,$id); if($stmt->execute()) $success='Updated.'; else $error='Failed.'; }
                }
            }
        }
        if ($action==='delete') {
            $id=(int)($_POST['user_id']??0);
            if ($id>0){ $stmt=$db->prepare("DELETE FROM users WHERE id=?"); $stmt->bind_param('i',$id); if($stmt->execute()) $success='Deleted.'; else $error='Failed.'; }
        }
    }
}
$search=sanitize($_GET['q']??'');
$raw=$db->query("SELECT * FROM users ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
$users=[];
foreach($raw as $u){
    $u['_name']=decrypt_data($u['fullname']); $u['_email']=decrypt_data($u['email']);
    $u['_phone']=decrypt_data($u['phone']);   $u['_address']=decrypt_data($u['address']);
    if(!$search||stripos($u['_name'],$search)!==false||stripos($u['_email'],$search)!==false) $users[]=$u;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Customers — ThreadVibe Admin</title>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="dashboard">
<?php require_once '../includes/admin_sidebar.php'; ?>
<div class="main-content">
    <div class="topbar">
        <div class="topbar-left">
            <button class="hamburger" id="hamburgerBtn" onclick="toggleSidebar()"><span></span><span></span><span></span></button>
            <div class="topbar-title">Customers</div>
        </div>
        <div class="topbar-right">
            <span class="topbar-user-name"><?= sanitize($_SESSION['admin_username']) ?></span>
            <div class="avatar"><?= strtoupper(substr($_SESSION['admin_username'],0,1)) ?></div>
        </div>
    </div>
    <div class="page-content">
        <?php if($error): ?><div class="alert alert-error"><i class="fa fa-circle-exclamation"></i> <?= $error ?></div><?php endif; ?>
        <?php if($success): ?><div class="alert alert-success"><i class="fa fa-circle-check"></i> <?= $success ?></div><?php endif; ?>
        <div class="card">
            <div class="card-header">
                <div class="card-title">All Customers (<?= count($users) ?>)</div>
                <button class="btn btn-primary btn-sm" onclick="openModal('createModal')"><i class="fa fa-user-plus"></i> Add</button>
            </div>
            <div class="card-body" style="padding-bottom:0">
                <form method="GET" class="search-bar">
                    <input type="text" name="q" placeholder="Search by name or email…" value="<?= sanitize($search) ?>">
                    <button type="submit" class="btn btn-outline btn-sm"><i class="fa fa-search"></i></button>
                    <?php if($search): ?><a href="users.php" class="btn btn-ghost btn-sm">Clear</a><?php endif; ?>
                </form>
            </div>
            <div class="table-responsive">
                <table>
                    <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Phone</th><th>Joined</th><th>Actions</th></tr></thead>
                    <tbody>
                    <?php if(empty($users)): ?>
                    <tr><td colspan="6"><div class="empty-state"><span class="empty-icon"><i class="fa fa-users"></i></span><p>No customers found.</p></div></td></tr>
                    <?php else: foreach($users as $u): ?>
                    <tr>
                        <td><?= $u['id'] ?></td>
                        <td style="color:var(--text);font-weight:500"><?= sanitize($u['_name']) ?></td>
                        <td><?= sanitize($u['_email']) ?></td>
                        <td><?= sanitize($u['_phone'])?:'—' ?></td>
                        <td><?= date('M d, Y',strtotime($u['created_at'])) ?></td>
                        <td style="white-space:nowrap">
                            <button class="btn btn-warning btn-sm" onclick="openEdit(<?= htmlspecialchars(json_encode(['id'=>$u['id'],'name'=>$u['_name'],'email'=>$u['_email'],'phone'=>$u['_phone'],'address'=>$u['_address']])) ?>)"><i class="fa fa-pen"></i></button>
                            <button class="btn btn-danger btn-sm" onclick="confirmDelete(<?= $u['id'] ?>,'<?= sanitize($u['_name']) ?>')"><i class="fa fa-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
<!-- Create -->
<div class="modal-overlay" id="createModal"><div class="modal">
    <div class="modal-header"><div class="modal-title">Add Customer</div><button class="modal-close" onclick="closeModal('createModal')"><i class="fa fa-xmark"></i></button></div>
    <form method="POST"><div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= $csrf ?>"><input type="hidden" name="action" value="create">
        <div class="form-row">
            <div class="form-group"><label>Full Name *</label><input type="text" name="fullname" required></div>
            <div class="form-group"><label>Email *</label><input type="email" name="email" required></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>Phone</label><input type="text" name="phone"></div>
            <div class="form-group"><label>Password * (8+ alphanumeric)</label>
                <div class="password-wrapper"><input type="password" name="password" id="c_pw" required minlength="8"><button type="button" class="pw-toggle" onclick="togglePw('c_pw','c_ic')"><i class="fa fa-eye" id="c_ic"></i></button></div>
            </div>
        </div>
        <div class="form-group"><label>Address</label><textarea name="address" rows="2"></textarea></div>
    </div>
    <div class="modal-footer"><button type="button" class="btn btn-ghost btn-sm" onclick="closeModal('createModal')">Cancel</button><button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-check"></i> Create</button></div>
    </form>
</div></div>
<!-- Edit -->
<div class="modal-overlay" id="editModal"><div class="modal">
    <div class="modal-header"><div class="modal-title">Edit Customer</div><button class="modal-close" onclick="closeModal('editModal')"><i class="fa fa-xmark"></i></button></div>
    <form method="POST"><div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= $csrf ?>"><input type="hidden" name="action" value="update"><input type="hidden" name="user_id" id="edit_id">
        <div class="form-row">
            <div class="form-group"><label>Full Name *</label><input type="text" name="fullname" id="edit_name" required></div>
            <div class="form-group"><label>Email *</label><input type="email" name="email" id="edit_email" required></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>Phone</label><input type="text" name="phone" id="edit_phone"></div>
            <div class="form-group"><label>New Password (blank = keep)</label>
                <div class="password-wrapper"><input type="password" name="password" id="e_pw" minlength="8"><button type="button" class="pw-toggle" onclick="togglePw('e_pw','e_ic')"><i class="fa fa-eye" id="e_ic"></i></button></div>
            </div>
        </div>
        <div class="form-group"><label>Address</label><textarea name="address" id="edit_address" rows="2"></textarea></div>
    </div>
    <div class="modal-footer"><button type="button" class="btn btn-ghost btn-sm" onclick="closeModal('editModal')">Cancel</button><button type="submit" class="btn btn-warning btn-sm"><i class="fa fa-floppy-disk"></i> Update</button></div>
    </form>
</div></div>
<!-- Delete -->
<div class="modal-overlay" id="deleteModal"><div class="modal" style="max-width:380px">
    <div class="modal-header"><div class="modal-title">Delete Customer</div></div>
    <form method="POST"><div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= $csrf ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="user_id" id="del_id">
        <p style="color:var(--text-muted)">Delete <strong id="del_name" style="color:var(--text)"></strong>? This cannot be undone.</p>
    </div>
    <div class="modal-footer"><button type="button" class="btn btn-ghost btn-sm" onclick="closeModal('deleteModal')">Cancel</button><button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Delete</button></div>
    </form>
</div></div>
<script src="../assets/js/sidebar.js"></script>
<script>
function openModal(id){document.getElementById(id).classList.add('active');}
function closeModal(id){document.getElementById(id).classList.remove('active');}
function openEdit(u){document.getElementById('edit_id').value=u.id;document.getElementById('edit_name').value=u.name;document.getElementById('edit_email').value=u.email;document.getElementById('edit_phone').value=u.phone;document.getElementById('edit_address').value=u.address;openModal('editModal');}
function confirmDelete(id,name){document.getElementById('del_id').value=id;document.getElementById('del_name').textContent=name;openModal('deleteModal');}
function togglePw(i,c){const el=document.getElementById(i),ic=document.getElementById(c);el.type==='password'?(el.type='text',ic.classList.replace('fa-eye','fa-eye-slash')):(el.type='password',ic.classList.replace('fa-eye-slash','fa-eye'));}
window.addEventListener('click',e=>{if(e.target.classList.contains('modal-overlay'))e.target.classList.remove('active');});
</script>
</body>
</html>
