<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ThreadVibe — Fashion Curated for You</title>
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
.landing-wrapper {
    min-height: 100vh; display: flex; align-items: stretch;
    background: var(--bg);
    position: relative; overflow: hidden;
}
.landing-bg {
    position: absolute; inset: 0; pointer-events: none;
    background:
        radial-gradient(ellipse 50% 60% at 20% 40%, rgba(201,168,76,0.06) 0%, transparent 60%),
        radial-gradient(ellipse 40% 50% at 80% 70%, rgba(201,168,76,0.04) 0%, transparent 60%);
}
.landing-grid-overlay {
    position: absolute; inset: 0; pointer-events: none;
    background-image:
        linear-gradient(var(--border) 1px, transparent 1px),
        linear-gradient(90deg, var(--border) 1px, transparent 1px);
    background-size: 60px 60px;
    opacity: 0.3;
    mask-image: radial-gradient(ellipse at center, black 30%, transparent 80%);
}
.landing-inner {
    position: relative; z-index: 1;
    display: flex; flex-direction: column; align-items: center; justify-content: center;
    min-height: 100vh; padding: 48px 24px; text-align: center; width: 100%;
}
.landing-eyebrow {
    font-size: 10px; text-transform: uppercase; letter-spacing: 4px;
    color: var(--gold); margin-bottom: 20px;
    display: flex; align-items: center; gap: 10px;
}
.landing-eyebrow::before, .landing-eyebrow::after {
    content: ''; display: block; width: 30px; height: 1px; background: var(--gold); opacity: .5;
}
.landing-logo {
    font-family: 'Playfair Display', serif;
    font-size: clamp(48px, 10vw, 92px);
    font-weight: 700; line-height: 1; letter-spacing: -2px;
    color: var(--text); margin-bottom: 8px;
}
.landing-logo span { color: var(--gold); font-style: italic; }
.landing-sub {
    font-size: 13px; letter-spacing: 3px; text-transform: uppercase;
    color: var(--text-muted); margin-bottom: 48px;
}
.landing-actions {
    display: flex; flex-direction: column; gap: 12px;
    width: 100%; max-width: 280px;
}
.landing-actions .btn { font-size: 11px; letter-spacing: 2px; padding: 14px 24px; }
.landing-footer {
    margin-top: 48px; font-size: 11px; color: var(--text-dim);
    letter-spacing: 1px; text-transform: uppercase;
}
.landing-footer span { color: var(--gold); opacity: .6; margin: 0 8px; }
</style>
</head>
<body>
<div class="landing-wrapper">
    <div class="landing-bg"></div>
    <div class="landing-grid-overlay"></div>
    <div class="landing-inner">
        <div class="landing-eyebrow">Est. 2026 · Ann Joshua</div>
        <div class="landing-logo">Thread<span>Vibe</span></div>
        <div class="landing-sub">Fashion Curated for You</div>
        <div class="landing-actions">
            <a href="user/login.php" class="btn btn-primary btn-block">
                <i class="fa fa-arrow-right-to-bracket"></i> Sign In
            </a>
            <a href="user/register.php" class="btn btn-outline btn-block">
                <i class="fa fa-user-plus"></i> Create Account
            </a>
        </div>
    </div>
</div>
</body>
</html>
