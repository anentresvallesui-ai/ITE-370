-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2026 at 12:05 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `threadvibe_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `email`, `password`, `created_at`) VALUES
(1, 'admin', 'admin@threadvibe.com', '$2y$12$lfXXysDKh4bfq8Tmkf24q.zHmM9hIy2MGgrqRuxHRi5clWG.Uhr..', '2026-02-28 10:42:02');

-- --------------------------------------------------------

--
-- Table structure for table `login_logs`
--

CREATE TABLE `login_logs` (
  `id` int(11) NOT NULL,
  `user_type` enum('admin','user') NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `login_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `login_logs`
--

INSERT INTO `login_logs` (`id`, `user_type`, `user_id`, `ip_address`, `login_time`) VALUES
(1, 'admin', 1, '::1', '2026-02-28 11:01:09'),
(2, 'admin', 1, '::1', '2026-02-28 11:04:17');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `stock`, `image`, `category`, `created_at`, `updated_at`) VALUES
(1, 'Oversized Linen Blazer', 'Relaxed-fit linen blazer in sand beige. Unlined, notch lapel, two patch pockets.', 2899.00, 30, NULL, 'Outerwear', '2026-02-28 10:42:02', '2026-02-28 10:42:02'),
(2, 'Merino Wool Turtleneck', 'Superfine 18.5-micron merino wool. Ribbed cuffs and hem. Ivory & Charcoal available.', 1899.00, 45, NULL, 'Tops', '2026-02-28 10:42:02', '2026-02-28 10:42:02'),
(3, 'Wide-Leg Tailored Trousers', 'Italian-cut wool-blend trousers. High rise, wide leg, fully lined. Camel & Black.', 2499.00, 35, NULL, 'Bottoms', '2026-02-28 10:42:02', '2026-02-28 10:42:02'),
(4, 'Silk Slip Dress', 'Charmeuse silk slip dress, adjustable spaghetti straps, bias cut. Champagne & Onyx.', 3299.00, 20, NULL, 'Dresses', '2026-02-28 10:42:02', '2026-02-28 10:42:02'),
(5, 'Structured Tote Bag', 'Full-grain leather tote, interior zip pocket, magnetic snap closure. Tan & Black.', 4499.00, 18, NULL, 'Accessories', '2026-02-28 10:42:02', '2026-02-28 10:42:02'),
(6, 'Cropped Denim Jacket', 'Vintage-wash 12oz denim, cropped silhouette, pearl-snap buttons. Light & Dark wash.', 2199.00, 40, NULL, 'Outerwear', '2026-02-28 10:42:02', '2026-02-28 10:42:02'),
(7, 'Pleated Midi Skirt', 'Knife-pleat satin midi skirt, elasticated waistband. Blush, Sage & Black.', 1699.00, 50, NULL, 'Bottoms', '2026-02-28 10:42:02', '2026-02-28 10:42:02'),
(8, 'Ribbed Tank Set', 'Matching ribbed viscose tank + shorts set. 6 colors. Loungewear meets streetwear.', 1499.00, 60, NULL, 'Sets', '2026-02-28 10:42:02', '2026-02-28 10:42:02'),
(9, 'Trench Coat Classic', 'Cotton-gabardine trench, double-breasted, removable belt. Camel & Navy.', 5499.00, 15, NULL, 'Outerwear', '2026-02-28 10:42:02', '2026-02-28 10:42:02'),
(10, 'Broderie Anglaise Blouse', 'Cotton broderie blouse, balloon sleeves, smocked cuffs. White & Dusty Rose.', 1599.00, 42, NULL, 'Tops', '2026-02-28 10:42:02', '2026-02-28 10:42:02'),
(11, 'High-Waist Straight Jeans', '100% cotton selvedge denim, high-rise, straight leg, raw hem. 4 washes.', 2299.00, 55, NULL, 'Bottoms', '2026-02-28 10:42:02', '2026-02-28 10:42:02'),
(12, 'Knit Mini Dress', 'Open-knit crochet-style mini dress. Fully lined. Beach-to-brunch versatility. Cream & Black.', 1999.00, 28, NULL, 'Dresses', '2026-02-28 10:42:02', '2026-02-28 10:42:02'),
(13, 'Leather Belt Bag', 'Pebbled leather belt bag, adjustable strap, gold hardware. Black & Cognac.', 1899.00, 25, NULL, 'Accessories', '2026-02-28 10:42:02', '2026-02-28 10:42:02'),
(14, 'Wrap Maxi Dress', 'Crepe-de-chine wrap dress, V-neck, flutter sleeves, self-tie waist. 5 prints.', 2699.00, 32, NULL, 'Dresses', '2026-02-28 10:42:02', '2026-02-28 10:42:02'),
(15, 'Cashmere Beanie', '100% Grade-A Mongolian cashmere ribbed beanie. 8 seasonal colors.', 999.00, 70, NULL, 'Accessories', '2026-02-28 10:42:02', '2026-02-28 10:42:02'),
(16, 'Floral Co-ord Set', 'Printed viscose crop top + wide-leg trouser co-ord. Limited edition floral print.', 2899.00, 22, NULL, 'Sets', '2026-02-28 10:42:02', '2026-02-28 10:42:02');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `email`, `password`, `phone`, `address`, `created_at`, `updated_at`) VALUES
(1, '6TMYZf7itsZvwi055HUTfkwzOTJtc0JFUzJEalZKS2NJcHRSR3c9PQ==', 'tRRdJ9AU8UwAzKF6lQ7pPEV5SVEvdllJUGMxYnRqU2RlOCs2bUE9PQ==', '$2y$12$spCL3vS/CawnqvQZb0WIgedSGQXVt.T3Kwnt5Ow9fb7/X7dQl4.VC', '', '', '2026-02-28 10:42:25', '2026-02-28 10:49:51');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `login_logs`
--
ALTER TABLE `login_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `login_logs`
--
ALTER TABLE `login_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
