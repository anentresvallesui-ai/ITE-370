<?php // includes/admin_sidebar.php ?>

<div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>

<nav class="sidebar" id="sidebar">
    <div class="sidebar-brand">
        <div>
            <div class="brand-wordmark">Thread<span>Vibe</span></div>
            <div class="brand-sub">Admin Studio</div>
        </div>
        <button class="sidebar-close" onclick="closeSidebar()"><i class="fa fa-xmark"></i></button>
    </div>
    <div class="sidebar-nav">
        <div class="nav-section">Overview</div>
        <div class="nav-item <?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>">
            <a href="dashboard.php" onclick="autoClose()"><span class="nav-icon"><i class="fa fa-chart-line"></i></span> Dashboard</a>
        </div>
        <div class="nav-section">Manage</div>
        <div class="nav-item <?= basename($_SERVER['PHP_SELF'])=='users.php'?'active':'' ?>">
            <a href="users.php" onclick="autoClose()"><span class="nav-icon"><i class="fa fa-users"></i></span> Customers</a>
        </div>
        <div class="nav-item <?= basename($_SERVER['PHP_SELF'])=='products.php'?'active':'' ?>">
            <a href="products.php" onclick="autoClose()"><span class="nav-icon"><i class="fa fa-shirt"></i></span> Products</a>
        </div>
        <div class="nav-section">Session</div>
        <div class="nav-item">
            <a href="#" onclick="event.preventDefault();openLogoutModal()"><span class="nav-icon"><i class="fa fa-arrow-right-from-bracket"></i></span> Logout</a>
        </div>
    </div>
</nav>

<div class="modal-overlay" id="logoutModal">
    <div class="modal" style="max-width:360px">
        <div class="modal-header"><div class="modal-title">Confirm Logout</div></div>
        <div class="modal-body" style="text-align:center;padding:30px 22px">
            <div style="font-size:40px;margin-bottom:14px;opacity:.5">👋</div>
            <p style="font-size:14px;color:var(--text-muted)">Are you sure you want to end your admin session?</p>
        </div>
        <div class="modal-footer" style="justify-content:center;gap:10px">
            <button class="btn btn-ghost btn-sm" onclick="closeLogoutModal()"><i class="fa fa-xmark"></i> Cancel</button>
            <a href="logout.php" class="btn btn-danger btn-sm"><i class="fa fa-arrow-right-from-bracket"></i> Logout</a>
        </div>
    </div>
</div>
<script>
function openLogoutModal()  { document.getElementById('logoutModal').classList.add('active'); }
function closeLogoutModal() { document.getElementById('logoutModal').classList.remove('active'); }
window.addEventListener('click', e => { if (e.target.id==='logoutModal') closeLogoutModal(); });
</script>
