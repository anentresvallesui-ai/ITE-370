<?php
require_once '../includes/user_auth.php';
$db=get_db();
$products=$db->query("SELECT * FROM products ORDER BY created_at DESC LIMIT 8")->fetch_all(MYSQLI_ASSOC);
$total=$db->query("SELECT COUNT(*) as c FROM products")->fetch_assoc()['c'];
$icons=['Tops'=>'👕','Bottoms'=>'👖','Dresses'=>'👗','Outerwear'=>'🧥','Sets'=>'🩱','Swimwear'=>'🩳','Activewear'=>'🏃','Accessories'=>'👜','Footwear'=>'👠','Other'=>'🛍️'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Home — ThreadVibe</title>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="dashboard">
<?php require_once '../includes/user_sidebar.php'; ?>
<div class="main-content">
    <div class="topbar">
        <div class="topbar-left">
            <button class="hamburger" id="hamburgerBtn" onclick="toggleSidebar()"><span></span><span></span><span></span></button>
            <div class="topbar-title">Home</div>
        </div>
        <div class="topbar-right">
            <span class="topbar-user-name"><?= sanitize($_SESSION['user_name']) ?></span>
            <div class="avatar"><?= strtoupper(substr($_SESSION['user_name'],0,1)) ?></div>
        </div>
    </div>
    <div class="page-content">
        <div class="dash-hero">
            <div class="dash-hero-eyebrow">New Season · New You</div>
            <h2>Hello, <?= sanitize($_SESSION['user_name']) ?> 👋</h2>
            <p>Discover curated fashion pieces — from timeless classics to the latest trends.</p>
            <div class="dash-hero-accent">🧵</div>
        </div>
        <div class="card">
            <div class="card-header">
                <div class="card-title">New Arrivals</div>
                <a href="products.php" class="btn btn-outline btn-sm"><i class="fa fa-arrow-right"></i> All Collections (<?= $total ?>)</a>
            </div>
            <div class="card-body">
                <?php if(empty($products)): ?>
                <div class="empty-state"><span class="empty-icon"><i class="fa fa-shirt"></i></span><p>No products yet. Check back soon!</p></div>
                <?php else: ?>
                <div class="products-grid">
                <?php foreach($products as $p): $icon=$icons[$p['category']]??'🛍️'; ?>
                <div class="product-card">
                    <div class="product-img">
                        <div class="product-cat-badge"><?= sanitize($p['category']) ?></div>
                        <?= $icon ?>
                    </div>
                    <div class="product-info">
                        <div class="product-name"><?= sanitize($p['name']) ?></div>
                        <div class="product-desc"><?= sanitize($p['description']) ?></div>
                        <div class="product-footer">
                            <div class="product-price">₱<?= number_format($p['price'],2) ?></div>
                            <div class="product-stock"><?= $p['stock']>0?"Stock: {$p['stock']}":'<span style="color:var(--danger)">Sold out</span>' ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
</div>
<script src="../assets/js/sidebar.js"></script>
</body>
</html>
