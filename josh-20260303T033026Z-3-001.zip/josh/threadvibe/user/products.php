<?php
require_once '../includes/user_auth.php';
$db=get_db();
$search=sanitize($_GET['q']??''); $category=sanitize($_GET['cat']??'');
$where='1=1'; $params=[]; $types='';
if($search){$where.=' AND (name LIKE ? OR description LIKE ?)';$like="%$search%";$params[]=$like;$params[]=$like;$types.='ss';}
if($category){$where.=' AND category=?';$params[]=$category;$types.='s';}
if($params){$stmt=$db->prepare("SELECT * FROM products WHERE $where ORDER BY name ASC");$stmt->bind_param($types,...$params);$stmt->execute();$products=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);}
else{$products=$db->query("SELECT * FROM products ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);}
$cats=$db->query("SELECT DISTINCT category FROM products ORDER BY category")->fetch_all(MYSQLI_ASSOC);
$icons=['Tops'=>'👕','Bottoms'=>'👖','Dresses'=>'👗','Outerwear'=>'🧥','Sets'=>'🩱','Swimwear'=>'🩳','Activewear'=>'🏃','Accessories'=>'👜','Footwear'=>'👠','Other'=>'🛍️'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Collections — ThreadVibe</title>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="dashboard">
<?php require_once '../includes/user_sidebar.php'; ?>
<div class="main-content">
    <div class="topbar">
        <div class="topbar-left">
            <button class="hamburger" id="hamburgerBtn" onclick="toggleSidebar()"><span></span><span></span><span></span></button>
            <div class="topbar-title">Collections</div>
        </div>
        <div class="topbar-right">
            <span class="topbar-user-name"><?= sanitize($_SESSION['user_name']) ?></span>
            <div class="avatar"><?= strtoupper(substr($_SESSION['user_name'],0,1)) ?></div>
        </div>
    </div>
    <div class="page-content">
        <form method="GET" style="display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap;">
            <input type="text" name="q" placeholder="Search clothing…" value="<?= sanitize($search) ?>"
                style="flex:1;min-width:140px;padding:11px 14px;background:var(--bg-3);border:1px solid var(--border);border-radius:var(--radius);color:var(--text);font-family:'DM Sans',sans-serif;font-size:13.5px;outline:none;transition:border-color .2s;"
                onfocus="this.style.borderColor='var(--gold)'" onblur="this.style.borderColor='var(--border)'">
            <select name="cat"
                style="padding:11px 14px;background:var(--bg-3);border:1px solid var(--border);border-radius:var(--radius);color:var(--text);font-family:'DM Sans',sans-serif;font-size:13.5px;outline:none;min-width:130px;">
                <option value="">All Categories</option>
                <?php foreach($cats as $c): ?><option value="<?= $c['category'] ?>" <?= $category===$c['category']?'selected':'' ?>><?= $c['category'] ?></option><?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-outline btn-sm"><i class="fa fa-search"></i> Search</button>
            <?php if($search||$category): ?><a href="products.php" class="btn btn-ghost btn-sm">Clear</a><?php endif; ?>
        </form>
        <p style="font-size:11px;text-transform:uppercase;letter-spacing:2px;color:var(--text-dim);margin-bottom:16px"><?= count($products) ?> item<?= count($products)!==1?'s':'' ?> found</p>
        <?php if(empty($products)): ?>
        <div class="empty-state"><span class="empty-icon"><i class="fa fa-shirt"></i></span><p>No products found.</p></div>
        <?php else: ?>
        <div class="products-grid">
        <?php foreach($products as $p): $icon=$icons[$p['category']]??'🛍️'; ?>
        <div class="product-card">
            <div class="product-img">
                <div class="product-cat-badge"><?= sanitize($p['category']) ?></div>
                <?= $icon ?>
            </div>
            <div class="product-info">
                <div class="product-name"><?= sanitize($p['name']) ?></div>
                <div class="product-desc"><?= sanitize($p['description'])?:'No description.' ?></div>
                <div class="product-footer">
                    <div class="product-price">₱<?= number_format($p['price'],2) ?></div>
                    <div class="product-stock"><?= $p['stock']>0?"Stock: {$p['stock']}":'<span style="color:var(--danger)">Sold out</span>' ?></div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>
</div>
<script src="../assets/js/sidebar.js"></script>
</body>
</html>
