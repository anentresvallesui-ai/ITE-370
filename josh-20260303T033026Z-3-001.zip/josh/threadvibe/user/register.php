<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/db.php';
if (isset($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }

$error=''; $success=''; $csrf=generate_csrf();

if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!verify_csrf($_POST['csrf_token']??'')) { $error='Invalid request.'; }
    else {
        $fn=sanitize($_POST['fullname']??''); $em=sanitize($_POST['email']??'');
        $pw=$_POST['password']??''; $cpw=$_POST['confirm_password']??'';
        if (empty($fn)||empty($em)||empty($pw)) { $error='All fields are required.'; }
        elseif (!filter_var($em,FILTER_VALIDATE_EMAIL)) { $error='Invalid email address.'; }
        elseif (!validate_password($pw)) { $error='Password must be at least 8 characters with letters and numbers.'; }
        elseif ($pw!==$cpw) { $error='Passwords do not match.'; }
        else {
            $db=get_db();
            $all=$db->query("SELECT email FROM users")->fetch_all(MYSQLI_ASSOC);
            $ex=false; foreach($all as $r){if(decrypt_data($r['email'])===$em){$ex=true;break;}}
            if ($ex) { $error='Email already registered.'; }
            else {
                $stmt=$db->prepare("INSERT INTO users (fullname,email,password) VALUES (?,?,?)");
                $a=encrypt_data($fn);$b=encrypt_data($em);$c=hash_password($pw);
                $stmt->bind_param('sss',$a,$b,$c);
                if($stmt->execute()) $success='Account created! You can now sign in.';
                else $error='Registration failed. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create Account — ThreadVibe</title>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="auth-wrapper">
    <div class="auth-visual">
        <div class="auth-visual-text">
            <div class="auth-visual-logo">Thread<span>Vibe</span></div>
            <div class="auth-visual-tagline">Join the Community</div>
            <div class="auth-visual-quote">Fashion is the armor to survive the reality of everyday life.</div>
        </div>
        <div class="auth-decorlines">
            <?php for($i=0;$i<5;$i++): ?><span style="--i:<?= $i ?>"></span><?php endfor; ?>
        </div>
    </div>
    <div class="auth-form-side">
        <div class="auth-card">
            <div class="auth-card-header">
                <h2>Create account</h2>
                <p>Join ThreadVibe and discover fashion</p>
            </div>
            <?php if($error): ?><div class="alert alert-error"><i class="fa fa-circle-exclamation"></i> <?= $error ?></div><?php endif; ?>
            <?php if($success): ?><div class="alert alert-success"><i class="fa fa-circle-check"></i> <?= $success ?></div><?php endif; ?>
            <?php if(!$success): ?>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                <div class="form-group"><label>Full Name *</label><input type="text" name="fullname" placeholder="Juan dela Cruz" required></div>
                <div class="form-group"><label>Email *</label><input type="email" name="email" placeholder="juan@email.com" required></div>
                <div class="form-group">
                    <label>Password * <span style="font-weight:300;font-size:10px;letter-spacing:.5px">(min. 8 chars, alphanumeric)</span></label>
                    <div class="password-wrapper">
                        <input type="password" name="password" id="pw1" placeholder="••••••••" required minlength="8">
                        <button type="button" class="pw-toggle" onclick="togglePw('pw1','ic1')"><i class="fa fa-eye" id="ic1"></i></button>
                    </div>
                </div>
                <div class="form-group">
                    <label>Confirm Password *</label>
                    <div class="password-wrapper">
                        <input type="password" name="confirm_password" id="pw2" placeholder="••••••••" required>
                        <button type="button" class="pw-toggle" onclick="togglePw('pw2','ic2')"><i class="fa fa-eye" id="ic2"></i></button>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-block"><i class="fa fa-user-plus"></i> Create Account</button>
            </form>
            <?php endif; ?>
            <div class="auth-links">Already have an account? <a href="login.php">Sign in</a></div>
        </div>
    </div>
</div>
<script>
function togglePw(i,c){const el=document.getElementById(i),ic=document.getElementById(c);el.type==='password'?(el.type='text',ic.classList.replace('fa-eye','fa-eye-slash')):(el.type='password',ic.classList.replace('fa-eye-slash','fa-eye'));}
</script>
</body>
</html>
