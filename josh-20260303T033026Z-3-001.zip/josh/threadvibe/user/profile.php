<?php
require_once '../includes/user_auth.php';
$db = get_db();
$error = '';
$success = '';
$csrf = generate_csrf();
$user_id = $_SESSION['user_id'];

$stmt = $db->prepare("SELECT * FROM users WHERE id=?");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
if (!$user) {
    session_destroy();
    header('Location: login.php');
    exit;
}
$user['_name'] = decrypt_data($user['fullname'] ?? '');
$user['_email'] = decrypt_data($user['email'] ?? '');
$user['_phone'] = decrypt_data($user['phone'] ?? '');
$user['_address'] = decrypt_data($user['address'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request.';
    } else {
        $action = $_POST['action'] ?? 'update';
        if ($action === 'update') {
            $fn = sanitize($_POST['fullname'] ?? '');
            $em = sanitize($_POST['email'] ?? '');
            $ph = sanitize($_POST['phone'] ?? '');
            $ad = sanitize($_POST['address'] ?? '');
            $pw = $_POST['password'] ?? '';
            $cpw = $_POST['confirm_password'] ?? '';
            $cur = $_POST['current_password'] ?? '';
            if (empty($fn) || empty($em)) {
                $error = 'Name and email required.';
            } elseif (!filter_var($em, FILTER_VALIDATE_EMAIL)) {
                $error = 'Invalid email.';
            } else {
                if (!empty($pw)) {
                    if (!verify_password($cur, $user['password'])) {
                        $error = 'Current password incorrect.';
                    } elseif (!validate_password($pw)) {
                        $error = 'New password: 8+ alphanumeric.';
                    } elseif ($pw !== $cpw) {
                        $error = 'Passwords do not match.';
                    }
                }
                if (!$error) {
                    if ($em !== $user['_email']) {
                        $all = $db->query("SELECT id, email FROM users")->fetch_all(MYSQLI_ASSOC);
                        foreach ($all as $r) {
                            if (decrypt_data($r['email']) === $em && (int) $r['id'] !== $user_id) {
                                $error = 'Email already used by another account.';
                                break;
                            }
                        }
                    }
                }
                if (!$error) {
                    $a = encrypt_data($fn);
                    $b = encrypt_data($em);
                    $c = encrypt_data($ph);
                    $d = encrypt_data($ad);
                    if (!empty($pw)) {
                        $e = hash_password($pw);
                        $stmt = $db->prepare("UPDATE users SET fullname=?,email=?,phone=?,address=?,password=? WHERE id=?");
                        $stmt->bind_param('sssssi', $a, $b, $c, $d, $e, $user_id);
                    } else {
                        $stmt = $db->prepare("UPDATE users SET fullname=?,email=?,phone=?,address=? WHERE id=?");
                        $stmt->bind_param('ssssi', $a, $b, $c, $d, $user_id);
                    }
                    if ($stmt->execute()) {
                        $_SESSION['user_name'] = $fn;
                        $success = 'Profile updated!';
                        $user['_name'] = $fn;
                        $user['_email'] = $em;
                        $user['_phone'] = $ph;
                        $user['_address'] = $ad;
                    } else {
                        $error = 'Update failed.';
                    }
                }
            }
        }
        if ($action === 'delete') {
            $pw = $_POST['delete_password'] ?? '';
            if (!verify_password($pw, $user['password'])) {
                $error = 'Incorrect password.';
            } else {
                $stmt = $db->prepare("DELETE FROM users WHERE id=?");
                $stmt->bind_param('i', $user_id);
                $stmt->execute();
                session_destroy();
                header('Location: login.php');
                exit;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile — ThreadVibe</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>

<body>
    <div class="dashboard">
        <?php require_once '../includes/user_sidebar.php'; ?>
        <div class="main-content">
            <div class="topbar">
                <div class="topbar-left">
                    <button class="hamburger" id="hamburgerBtn"
                        onclick="toggleSidebar()"><span></span><span></span><span></span></button>
                    <div class="topbar-title">My Profile</div>
                </div>
                <div class="topbar-right">
                    <span class="topbar-user-name"><?= sanitize($_SESSION['user_name']) ?></span>
                    <div class="avatar"><?= strtoupper(substr($_SESSION['user_name'], 0, 1)) ?></div>
                </div>
            </div>
            <div class="page-content">
                <?php if ($error): ?>
                    <div class="alert alert-error"><i class="fa fa-circle-exclamation"></i> <?= $error ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="alert alert-success"><i class="fa fa-circle-check"></i> <?= $success ?></div><?php endif; ?>

                <div class="profile-header">
                    <div class="profile-avatar"><?= strtoupper(substr($user['_name'], 0, 1)) ?></div>
                    <div>
                        <div class="profile-name"><?= sanitize($user['_name']) ?></div>
                        <div class="profile-email"><i class="fa fa-envelope"
                                style="color:var(--gold);font-size:11px"></i> <?= sanitize($user['_email']) ?></div>
                        <div class="profile-since">Member since <?= date('F Y', strtotime($user['created_at'])) ?></div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <div class="card-title">Update Profile</div>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                            <input type="hidden" name="action" value="update">
                            <div class="form-row">
                                <div class="form-group"><label>Full Name *</label><input type="text" name="fullname"
                                        value="<?= sanitize($user['_name']) ?>" required></div>
                                <div class="form-group"><label>Email *</label><input type="email" name="email"
                                        value="<?= sanitize($user['_email']) ?>" required></div>
                            </div>
                            <div class="form-row">
                                <div class="form-group"><label>Phone</label><input type="text" name="phone"
                                        value="<?= sanitize($user['_phone']) ?>"></div>
                                <div class="form-group"><label>Address</label><input type="text" name="address"
                                        value="<?= sanitize($user['_address']) ?>"></div>
                            </div>
                            <hr style="border:none;border-top:1px solid var(--border);margin:20px 0;">
                            <p
                                style="font-size:11px;text-transform:uppercase;letter-spacing:1.5px;color:var(--text-dim);margin-bottom:14px">
                                <i class="fa fa-lock"></i> Change Password <span style="font-weight:300">(leave blank to
                                    keep current)</span></p>
                            <div class="form-row">
                                <div class="form-group"><label>Current Password</label>
                                    <div class="password-wrapper"><input type="password" name="current_password" id="cp"
                                            placeholder="••••••••"><button type="button" class="pw-toggle"
                                            onclick="togglePw('cp','cpi')"><i class="fa fa-eye" id="cpi"></i></button>
                                    </div>
                                </div>
                                <div class="form-group"><label>New Password (8+ alphanumeric)</label>
                                    <div class="password-wrapper"><input type="password" name="password" id="np"
                                            minlength="8"><button type="button" class="pw-toggle"
                                            onclick="togglePw('np','npi')"><i class="fa fa-eye" id="npi"></i></button>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group"><label>Confirm New Password</label>
                                <div class="password-wrapper"><input type="password" name="confirm_password"
                                        id="cnp"><button type="button" class="pw-toggle"
                                        onclick="togglePw('cnp','cnpi')"><i class="fa fa-eye" id="cnpi"></i></button>
                                </div>
                            </div>
                            <p style="font-size:11px;color:var(--text-dim);margin-bottom:16px"><i
                                    class="fa fa-shield-halved"></i> All data encrypted · Password hashed with bcrypt
                            </p>
                            <button type="submit" class="btn btn-primary"><i class="fa fa-floppy-disk"></i> Save
                                Changes</button>
                        </form>
                    </div>
                </div>

                <div class="card" style="border-color:rgba(224,82,82,0.3)">
                    <div class="card-header" style="border-color:rgba(224,82,82,0.2)">
                        <div class="card-title" style="color:var(--danger)"><i class="fa fa-triangle-exclamation"></i>
                            Danger Zone</div>
                    </div>
                    <div class="card-body">
                        <p style="color:var(--text-muted);margin-bottom:14px;font-size:13.5px">Permanently delete your
                            account and all associated data.</p>
                        <button class="btn btn-danger btn-sm" onclick="openModal('deleteModal')"><i
                                class="fa fa-trash"></i> Delete Account</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal-overlay" id="deleteModal">
        <div class="modal" style="max-width:400px">
            <div class="modal-header">
                <div class="modal-title" style="color:var(--danger)">Delete Account</div><button class="modal-close"
                    onclick="closeModal('deleteModal')"><i class="fa fa-xmark"></i></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="csrf_token" value="<?= $csrf ?>"><input type="hidden" name="action"
                        value="delete">
                    <div class="alert alert-error">This will permanently delete your account and cannot be undone.</div>
                    <div class="form-group"><label>Enter password to confirm</label>
                        <div class="password-wrapper"><input type="password" name="delete_password" id="dp"
                                required><button type="button" class="pw-toggle" onclick="togglePw('dp','dpi')"><i
                                    class="fa fa-eye" id="dpi"></i></button></div>
                    </div>
                </div>
                <div class="modal-footer"><button type="button" class="btn btn-ghost btn-sm"
                        onclick="closeModal('deleteModal')">Cancel</button><button type="submit"
                        class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Yes, Delete</button></div>
            </form>
        </div>
    </div>

    <script src="../assets/js/sidebar.js"></script>
    <script>
        function openModal(id) { document.getElementById(id).classList.add('active'); }
        function closeModal(id) { document.getElementById(id).classList.remove('active'); }
        function togglePw(i, c) { const el = document.getElementById(i), ic = document.getElementById(c); el.type === 'password' ? (el.type = 'text', ic.classList.replace('fa-eye', 'fa-eye-slash')) : (el.type = 'password', ic.classList.replace('fa-eye-slash', 'fa-eye')); }
        window.addEventListener('click', e => { if (e.target.classList.contains('modal-overlay')) e.target.classList.remove('active'); });
    </script>
</body>

</html>