<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/db.php';
if (isset($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }

$error=''; $csrf=generate_csrf();

if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!verify_csrf($_POST['csrf_token']??'')) { $error='Invalid request.'; }
    else {
        $email=sanitize($_POST['email']??''); $password=$_POST['password']??'';
        if (empty($email)||empty($password)) { $error='Please fill in all fields.'; }
        else {
            $db=get_db();
            $all=$db->query("SELECT id,fullname,email,password FROM users")->fetch_all(MYSQLI_ASSOC);
            $found=null;
            foreach($all as $u){ if(decrypt_data($u['email'])===$email){ $found=$u; break; } }
            if ($found&&verify_password($password,$found['password'])) {
                $_SESSION['user_id']=  $found['id'];
                $_SESSION['user_name']=decrypt_data($found['fullname']);
                header('Location: dashboard.php'); exit;
            } else { $error='Invalid email or password.'; }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In — ThreadVibe</title>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="auth-wrapper">
    <div class="auth-visual">
        <div class="auth-visual-text">
            <div class="auth-visual-logo">Thread<span>Vibe</span></div>
            <div class="auth-visual-tagline">Fashion Curated for You</div>
            <div class="auth-visual-quote">Dress like you're already famous.</div>
        </div>
        <div class="auth-decorlines">
            <?php for($i=0;$i<5;$i++): ?><span style="--i:<?= $i ?>"></span><?php endfor; ?>
        </div>
    </div>
    <div class="auth-form-side">
        <div class="auth-card">
            <div class="auth-card-header">
                <h2>Welcome back</h2>
                <p>Sign in to your ThreadVibe account</p>
            </div>
            <?php if($error): ?><div class="alert alert-error"><i class="fa fa-circle-exclamation"></i> <?= $error ?></div><?php endif; ?>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                <div class="form-group"><label>Email</label><input type="email" name="email" placeholder="your@email.com" required></div>
                <div class="form-group">
                    <label>Password</label>
                    <div class="password-wrapper">
                        <input type="password" name="password" id="pw" placeholder="••••••••" required>
                        <button type="button" class="pw-toggle" onclick="togglePw('pw','ico')"><i class="fa fa-eye" id="ico"></i></button>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-block" style="margin-top:8px"><i class="fa fa-arrow-right-to-bracket"></i> Sign In</button>
            </form>
            <div class="divider">or</div>
            <div class="auth-links">New to ThreadVibe? <a href="register.php">Create an account</a></div>
        </div>
    </div>
</div>
<script>
function togglePw(i,c){const el=document.getElementById(i),ic=document.getElementById(c);el.type==='password'?(el.type='text',ic.classList.replace('fa-eye','fa-eye-slash')):(el.type='password',ic.classList.replace('fa-eye-slash','fa-eye'));}
</script>
</body>
</html>
